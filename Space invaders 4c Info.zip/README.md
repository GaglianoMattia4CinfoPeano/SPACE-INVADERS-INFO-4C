# Java-Threads-Space-Invaders
Un gioco di Space Invaders dove c'� l'uso di programmazione dei multi-threading
